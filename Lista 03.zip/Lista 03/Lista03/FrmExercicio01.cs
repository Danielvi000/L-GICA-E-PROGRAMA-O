﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista03
{
    public partial class FrmExercício1 : Form
    {
        public FrmExercício1()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {

        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            //Pegar da tela
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text); 
            float num3 = float.Parse(txtNum3.Text);
            float media;

            //Processamento
            media = (num1 + num2 + num3) / 3;

            //Saída
            lblRMedia.Text = "Media igual a " + media;
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            //A porcentagem de cada número em relação ao total
            float
        }
    }
    }
}
