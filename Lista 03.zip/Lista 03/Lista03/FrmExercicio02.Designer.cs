﻿namespace Lista03
{
    partial class FrmExercicio02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlBase = new System.Windows.Forms.Panel();
            this.lblResultado = new System.Windows.Forms.Label();
            this.lblVlrPagar = new System.Windows.Forms.Label();
            this.lblVlrLitro = new System.Windows.Forms.Label();
            this.txtVlrPagar = new System.Windows.Forms.TextBox();
            this.txtVlrLitro = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.pnlTopo.SuspendLayout();
            this.pnlBase.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTopo
            // 
            this.pnlTopo.BackColor = System.Drawing.Color.Crimson;
            this.pnlTopo.Controls.Add(this.label1);
            this.pnlTopo.Location = new System.Drawing.Point(2, 0);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(799, 123);
            this.pnlTopo.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(10, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(364, 73);
            this.label1.TabIndex = 0;
            this.label1.Text = "Exercicio02";
            // 
            // pnlBase
            // 
            this.pnlBase.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pnlBase.Controls.Add(this.lblResultado);
            this.pnlBase.Location = new System.Drawing.Point(2, 331);
            this.pnlBase.Name = "pnlBase";
            this.pnlBase.Size = new System.Drawing.Size(798, 123);
            this.pnlBase.TabIndex = 1;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(242, 42);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(268, 42);
            this.lblResultado.TabIndex = 0;
            this.lblResultado.Text = "Resultado aqui";
            // 
            // lblVlrPagar
            // 
            this.lblVlrPagar.AutoSize = true;
            this.lblVlrPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlrPagar.ForeColor = System.Drawing.Color.Transparent;
            this.lblVlrPagar.Location = new System.Drawing.Point(38, 171);
            this.lblVlrPagar.Name = "lblVlrPagar";
            this.lblVlrPagar.Size = new System.Drawing.Size(321, 42);
            this.lblVlrPagar.TabIndex = 2;
            this.lblVlrPagar.Text = "VALOR A PAGAR";
            // 
            // lblVlrLitro
            // 
            this.lblVlrLitro.AutoSize = true;
            this.lblVlrLitro.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlrLitro.ForeColor = System.Drawing.Color.Transparent;
            this.lblVlrLitro.Location = new System.Drawing.Point(38, 250);
            this.lblVlrLitro.Name = "lblVlrLitro";
            this.lblVlrLitro.Size = new System.Drawing.Size(330, 42);
            this.lblVlrLitro.TabIndex = 3;
            this.lblVlrLitro.Text = "VALOR DO LITRO";
            // 
            // txtVlrPagar
            // 
            this.txtVlrPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVlrPagar.Location = new System.Drawing.Point(396, 164);
            this.txtVlrPagar.Name = "txtVlrPagar";
            this.txtVlrPagar.Size = new System.Drawing.Size(213, 49);
            this.txtVlrPagar.TabIndex = 4;
            // 
            // txtVlrLitro
            // 
            this.txtVlrLitro.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVlrLitro.Location = new System.Drawing.Point(396, 250);
            this.txtVlrLitro.Name = "txtVlrLitro";
            this.txtVlrLitro.Size = new System.Drawing.Size(213, 49);
            this.txtVlrLitro.TabIndex = 5;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(649, 184);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(139, 91);
            this.btnCalcular.TabIndex = 6;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // FrmExercicio02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtVlrLitro);
            this.Controls.Add(this.txtVlrPagar);
            this.Controls.Add(this.lblVlrLitro);
            this.Controls.Add(this.lblVlrPagar);
            this.Controls.Add(this.pnlBase);
            this.Controls.Add(this.pnlTopo);
            this.Name = "FrmExercicio02";
            this.Text = "FrmExercicio2";
            this.pnlTopo.ResumeLayout(false);
            this.pnlTopo.PerformLayout();
            this.pnlBase.ResumeLayout(false);
            this.pnlBase.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.Panel pnlBase;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label lblVlrPagar;
        private System.Windows.Forms.Label lblVlrLitro;
        private System.Windows.Forms.TextBox txtVlrPagar;
        private System.Windows.Forms.TextBox txtVlrLitro;
        private System.Windows.Forms.Button btnCalcular;
    }
}