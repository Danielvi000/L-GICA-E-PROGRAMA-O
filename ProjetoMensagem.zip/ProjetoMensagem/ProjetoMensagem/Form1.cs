﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoMensagem
{
    public partial class FrmEnvioMensagem : Form
    {
        public FrmEnvioMensagem()
        {
            InitializeComponent();
        }

        private void FrmEnvioMensagem_Load(object sender, EventArgs e)
        {
            MessageBox.Show("abriu o formulário");
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no botão mostrar");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no botão limpar");
        }

        private void lblInteiro_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei na label inteiro");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterei um texto");
        }
    }
}
