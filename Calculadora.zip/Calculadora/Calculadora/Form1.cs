﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class FrmCalculadora : Form
    {
        public FrmCalculadora()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            //Criar variáveis e capturar dados da tela
            float valorNumero1 = float.Parse(txtNumero1.Text);
            float valorNumero2 = float.Parse(txtNumero2.Text);
            float soma;

            //Processamento - operação
            soma = valorNumero1 + valorNumero2;

            //Saída
            MessageBox.Show(" A soma é igual a " + soma);
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            //Criar variável e capturar dados da tela
            float valorNumero1 = float.Parse(txtNumero1.Text);
            float valorNumero2 = float.Parse(txtNumero2.Text);
            float subtracao;

            //Processamento - operação
            subtracao = valorNumero1 - valorNumero2;

            //Saída
            MessageBox.Show(" A subtração é igual a " + subtracao);
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            //Criar variável e capturar dados da tela
            float valorNumero1 = float.Parse(txtNumero1.Text);
            float valorNumero2 = float.Parse(txtNumero2.Text);
            float multiplicacao;

            //Processamento - operação
            multiplicacao = valorNumero1 * valorNumero2;

            //Saída
            MessageBox.Show(" A multiplicação é igual a " + multiplicacao);
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            //Criar variável e capturar dados da tela
            float valorNumero1 = float.Parse(txtNumero1.Text);
            float valorNumero2 = float.Parse(txtNumero2.Text);
            float divisao;

            //Processamento - operação
            divisao = valorNumero1 / valorNumero2;

            //Saída
            MessageBox.Show(" A divisão é igual a " + divisao);
        }
    }
}
