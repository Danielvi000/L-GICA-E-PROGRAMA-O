﻿namespace AppSimProva_Daniel_2B2
{
    partial class FrmQuestao01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.lblCEMIG = new System.Windows.Forms.Label();
            this.lblContaEnergia = new System.Windows.Forms.Label();
            this.pnlBase = new System.Windows.Forms.Panel();
            this.lblNomedaEmpresa = new System.Windows.Forms.Label();
            this.lblValorKWh = new System.Windows.Forms.Label();
            this.lblQuantidade = new System.Windows.Forms.Label();
            this.lblDiasAtraso = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtNomedaEmpresa = new System.Windows.Forms.TextBox();
            this.txtValorKWh = new System.Windows.Forms.TextBox();
            this.txtQuantidade = new System.Windows.Forms.TextBox();
            this.txtDiasAtraso = new System.Windows.Forms.TextBox();
            this.lblValorPagar = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.pnlTopo.SuspendLayout();
            this.pnlBase.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTopo
            // 
            this.pnlTopo.BackColor = System.Drawing.Color.DarkGreen;
            this.pnlTopo.Controls.Add(this.lblContaEnergia);
            this.pnlTopo.Controls.Add(this.lblCEMIG);
            this.pnlTopo.Location = new System.Drawing.Point(0, 0);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(1033, 165);
            this.pnlTopo.TabIndex = 0;
            // 
            // lblCEMIG
            // 
            this.lblCEMIG.AutoSize = true;
            this.lblCEMIG.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCEMIG.ForeColor = System.Drawing.Color.Transparent;
            this.lblCEMIG.Location = new System.Drawing.Point(50, 48);
            this.lblCEMIG.Name = "lblCEMIG";
            this.lblCEMIG.Size = new System.Drawing.Size(242, 73);
            this.lblCEMIG.TabIndex = 0;
            this.lblCEMIG.Text = "CEMIG";
            // 
            // lblContaEnergia
            // 
            this.lblContaEnergia.AutoSize = true;
            this.lblContaEnergia.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContaEnergia.ForeColor = System.Drawing.Color.Transparent;
            this.lblContaEnergia.Location = new System.Drawing.Point(761, 126);
            this.lblContaEnergia.Name = "lblContaEnergia";
            this.lblContaEnergia.Size = new System.Drawing.Size(257, 25);
            this.lblContaEnergia.TabIndex = 1;
            this.lblContaEnergia.Text = "Conta de Energia Elétrica";
            // 
            // pnlBase
            // 
            this.pnlBase.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pnlBase.Controls.Add(this.lblResultado);
            this.pnlBase.Controls.Add(this.lblValorPagar);
            this.pnlBase.Controls.Add(this.txtDiasAtraso);
            this.pnlBase.Controls.Add(this.txtQuantidade);
            this.pnlBase.Controls.Add(this.txtValorKWh);
            this.pnlBase.Controls.Add(this.txtNomedaEmpresa);
            this.pnlBase.Controls.Add(this.btnCalcular);
            this.pnlBase.Controls.Add(this.lblDiasAtraso);
            this.pnlBase.Controls.Add(this.lblQuantidade);
            this.pnlBase.Controls.Add(this.lblValorKWh);
            this.pnlBase.Controls.Add(this.lblNomedaEmpresa);
            this.pnlBase.Location = new System.Drawing.Point(0, 172);
            this.pnlBase.Name = "pnlBase";
            this.pnlBase.Size = new System.Drawing.Size(1033, 320);
            this.pnlBase.TabIndex = 1;
            // 
            // lblNomedaEmpresa
            // 
            this.lblNomedaEmpresa.AutoSize = true;
            this.lblNomedaEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomedaEmpresa.ForeColor = System.Drawing.Color.Transparent;
            this.lblNomedaEmpresa.Location = new System.Drawing.Point(58, 27);
            this.lblNomedaEmpresa.Name = "lblNomedaEmpresa";
            this.lblNomedaEmpresa.Size = new System.Drawing.Size(302, 25);
            this.lblNomedaEmpresa.TabIndex = 0;
            this.lblNomedaEmpresa.Text = "Nome da Empresa/Residência";
            // 
            // lblValorKWh
            // 
            this.lblValorKWh.AutoSize = true;
            this.lblValorKWh.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorKWh.ForeColor = System.Drawing.Color.Transparent;
            this.lblValorKWh.Location = new System.Drawing.Point(58, 117);
            this.lblValorKWh.Name = "lblValorKWh";
            this.lblValorKWh.Size = new System.Drawing.Size(114, 25);
            this.lblValorKWh.TabIndex = 1;
            this.lblValorKWh.Text = "Valor KWh";
            // 
            // lblQuantidade
            // 
            this.lblQuantidade.AutoSize = true;
            this.lblQuantidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantidade.ForeColor = System.Drawing.Color.Transparent;
            this.lblQuantidade.Location = new System.Drawing.Point(394, 117);
            this.lblQuantidade.Name = "lblQuantidade";
            this.lblQuantidade.Size = new System.Drawing.Size(237, 25);
            this.lblQuantidade.TabIndex = 2;
            this.lblQuantidade.Text = "Quantidade Consumida";
            // 
            // lblDiasAtraso
            // 
            this.lblDiasAtraso.AutoSize = true;
            this.lblDiasAtraso.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiasAtraso.ForeColor = System.Drawing.Color.Transparent;
            this.lblDiasAtraso.Location = new System.Drawing.Point(805, 117);
            this.lblDiasAtraso.Name = "lblDiasAtraso";
            this.lblDiasAtraso.Size = new System.Drawing.Size(158, 25);
            this.lblDiasAtraso.TabIndex = 3;
            this.lblDiasAtraso.Text = "Dias em Atraso";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(255, 227);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(486, 74);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseCompatibleTextRendering = true;
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtNomedaEmpresa
            // 
            this.txtNomedaEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomedaEmpresa.Location = new System.Drawing.Point(63, 70);
            this.txtNomedaEmpresa.Name = "txtNomedaEmpresa";
            this.txtNomedaEmpresa.Size = new System.Drawing.Size(297, 44);
            this.txtNomedaEmpresa.TabIndex = 5;
            // 
            // txtValorKWh
            // 
            this.txtValorKWh.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorKWh.Location = new System.Drawing.Point(63, 154);
            this.txtValorKWh.Name = "txtValorKWh";
            this.txtValorKWh.Size = new System.Drawing.Size(160, 31);
            this.txtValorKWh.TabIndex = 6;
            // 
            // txtQuantidade
            // 
            this.txtQuantidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuantidade.Location = new System.Drawing.Point(399, 154);
            this.txtQuantidade.Name = "txtQuantidade";
            this.txtQuantidade.Size = new System.Drawing.Size(259, 31);
            this.txtQuantidade.TabIndex = 7;
            // 
            // txtDiasAtraso
            // 
            this.txtDiasAtraso.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiasAtraso.Location = new System.Drawing.Point(794, 154);
            this.txtDiasAtraso.Name = "txtDiasAtraso";
            this.txtDiasAtraso.Size = new System.Drawing.Size(196, 31);
            this.txtDiasAtraso.TabIndex = 8;
            // 
            // lblValorPagar
            // 
            this.lblValorPagar.AutoSize = true;
            this.lblValorPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorPagar.ForeColor = System.Drawing.Color.Gold;
            this.lblValorPagar.Location = new System.Drawing.Point(632, 42);
            this.lblValorPagar.Name = "lblValorPagar";
            this.lblValorPagar.Size = new System.Drawing.Size(143, 25);
            this.lblValorPagar.TabIndex = 9;
            this.lblValorPagar.Text = "Valor a Pagar";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.ForeColor = System.Drawing.Color.Gold;
            this.lblResultado.Location = new System.Drawing.Point(837, 42);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(19, 25);
            this.lblResultado.TabIndex = 10;
            this.lblResultado.Text = "-";
            // 
            // FrmQuestao01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1030, 485);
            this.Controls.Add(this.pnlBase);
            this.Controls.Add(this.pnlTopo);
            this.Name = "FrmQuestao01";
            this.Text = "Form1";
            this.pnlTopo.ResumeLayout(false);
            this.pnlTopo.PerformLayout();
            this.pnlBase.ResumeLayout(false);
            this.pnlBase.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.Label lblContaEnergia;
        private System.Windows.Forms.Label lblCEMIG;
        private System.Windows.Forms.Panel pnlBase;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label lblValorPagar;
        private System.Windows.Forms.TextBox txtDiasAtraso;
        private System.Windows.Forms.TextBox txtQuantidade;
        private System.Windows.Forms.TextBox txtValorKWh;
        private System.Windows.Forms.TextBox txtNomedaEmpresa;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblDiasAtraso;
        private System.Windows.Forms.Label lblQuantidade;
        private System.Windows.Forms.Label lblValorKWh;
        private System.Windows.Forms.Label lblNomedaEmpresa;
    }
}

