﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_Daniel_2B2
{
    public partial class FrmQuestao01 : Form
    {
        public FrmQuestao01()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Primeiro pegue os valores da tela
            string nomeEmpresa = txtNomedaEmpresa.Text;
            float valorKWh = float.Parse(txtValorKWh.Text);
            float qtdConsumida = float.Parse(txtQuantidade.Text);
            int diasAtraso = int.Parse(txtDiasAtraso.Text);
            float resultado;

            //Esse é o cálculo
            resultado = (valorKWh * qtdConsumida) + (valorKWh * qtdConsumida * 1.5f/100 * diasAtraso);

            //Resultado
            lblResultado.Text = resultado.ToString("C");
        }
    }
}
